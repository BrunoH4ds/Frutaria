user_data = [("admin@gmail.com", "adminnotoque1234")]

Nome_Estoque = ['banana', 'laranja', 'maçã', 'uva', 'ameixa']
Quantidade_Estoque = {
     'banana': 10,
     'laranja': 20,
     'maçã': 3,
     'uva': 5,
     'ameixa': 50
 }
Preco_Estoque = {
     'banana': 1.75,
     'laranja': 2.00,
     'maçã': 3.00,
     'uva': 4.00,
     'ameixa': 5.00
 }