from tkinter import *
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.style import Style
from data import user_data,Nome_Estoque,Quantidade_Estoque,Preco_Estoque

class FrutariaAPP:
    def __init__(self, root):
        self.root = root
        self.Listas()
        self.Criacao_widgets()

    def Listas(self):
        self.Nome_Estoque = Nome_Estoque
        self.Quantidade_Estoque = Quantidade_Estoque
        self.Preco_Estoque = Preco_Estoque
        
        self.fruta_selecionada = []
        self.Valor_total = 0
        self.quantidade2 = 0

    def Criacao_widgets(self):
        self.main_frame = ttk.Frame(self.root)
        self.main_frame.pack(pady=10, padx=10, fill="both", expand=True)
        
        self.Painel_SignUp = ttk.Frame(self.main_frame)
        self.Painel_SignUp.pack(fill='both', expand=False)
        self.Painel_Admin = ttk.Frame(self.main_frame)
        self.Painel_Admin.pack(fill='both', expand=False)
        self.Painel_Cliente = ttk.Frame(self.main_frame)
        self.Painel_Cliente.pack(fill='both', expand=False)
        self.Painel_Login = ttk.Frame(self.main_frame)
        self.Painel_Login.pack(fill='both', expand=False)

        self.P_Cliente()
        self.P_Admin()
        self.Criacao_login_widgets()
        self.Criacao_signup_widgets()
        
        self.Painel_Cliente.pack_forget()
        self.Painel_Admin.pack_forget()
        self.Painel_SignUp.pack_forget()
        self.Painel_Login.pack(fill="both", expand=True)

    def Criacao_login_widgets(self):
        ttk.Label(self.Painel_Login, text="Login", font=("arial", 18)).pack(padx=10, pady=10, fill="y")

        Email = ttk.Frame(self.Painel_Login)
        Email.pack(pady=10, fill='x')
        ttk.Label(Email, text='Gmail:', font=("arial", 18)).pack(side=LEFT, padx=5)
        self.Email_Entry = ttk.Entry(Email, font=("arial", 12))
        self.Email_Entry.pack(side=LEFT, fill="x", expand=True, padx=5)

        Senha = ttk.Frame(self.Painel_Login)
        Senha.pack(pady=10, fill='x')
        ttk.Label(Senha, text='Senha:', font=("arial", 18)).pack(side=LEFT, padx=5)
        self.Senha_Entry = ttk.Entry(Senha, font=("arial", 12), show="*")
        self.Senha_Entry.pack(side=LEFT, fill="x", expand=True, padx=5)

        checkbt = ttk.Frame(self.Painel_Login)
        checkbt.pack(pady=10, padx=10, fill="x")
        ttk.Checkbutton(checkbt, text="Deseja salvar os dados de login?", bootstyle="round-toggle").pack(side=LEFT, padx=10)

        botao = ttk.Frame(self.Painel_Login)
        botao.pack(padx=30, pady=10)
        ttk.Button(botao, text="Entrar", bootstyle=SUCCESS, command=self.Login).pack(side=LEFT, padx=10)
        ttk.Button(botao, text="Sign Up", bootstyle=PRIMARY, command=self.janela_login_signUp).pack(side=RIGHT, padx=10)

        Resultado = ttk.Frame(self.Painel_Login)
        Resultado.pack(pady=10, fill="x")
        self.Resultado_label = ttk.Label(Resultado, text="", font=("Danger", 12))
        self.Resultado_label.pack()

    def Criacao_signup_widgets(self):
        ttk.Label(self.Painel_SignUp, text="Sign Up", font=("arial", 18)).pack(padx=10, pady=10, fill="y")

        Email2 = ttk.Frame(self.Painel_SignUp)
        Email2.pack(pady=10, fill='x')
        ttk.Label(Email2, text='Gmail:', font=("arial", 18)).pack(side=LEFT, padx=5)
        self.Email_Entry2 = ttk.Entry(Email2, font=("arial", 12))
        self.Email_Entry2.pack(side=LEFT, fill="x", expand=True, padx=5)

        Senha2 = ttk.Frame(self.Painel_SignUp)
        Senha2.pack(pady=10, fill='x')
        ttk.Label(Senha2, text='Senha:', font=("arial", 18)).pack(side=LEFT, padx=5)
        self.Senha_Entry2 = ttk.Entry(Senha2, font=("arial", 12), show="*")
        self.Senha_Entry2.pack(side=LEFT, fill="x", expand=True, padx=5)

        botao2 = ttk.Frame(self.Painel_SignUp)
        botao2.pack(padx=30, pady=10)
        ttk.Button(botao2, text="Cadastrar", bootstyle=SUCCESS, command=self.Sign_Up).pack(side=LEFT, padx=10)
        ttk.Button(botao2, text="Login", bootstyle=PRIMARY, command=self.janela_signUp_login).pack(side=RIGHT, padx=10)

        Resultado2 = ttk.Frame(self.Painel_SignUp)
        Resultado2.pack(pady=10, fill="x")
        self.Resultado_label2 = ttk.Label(Resultado2, text="", font=("Danger", 12))
        self.Resultado_label2.pack()

    def P_Cliente(self):
        ttk.Label(self.Painel_Cliente, text="Seja bem-vindo", font=("arial", 24)).pack(padx=10, pady=10, fill="y")

        fruta = ttk.Frame(self.Painel_Cliente)
        fruta.pack(pady=5, padx=5, fill='x')
        label_fruta = ttk.Label(fruta, text="Escolha a fruta:", font=('arial', 9))
        label_fruta.pack(pady=5, padx=10, fill='x')

        self.fruta_var = StringVar()
        self.combo_fruta = ttk.Combobox(fruta, textvariable=self.fruta_var, values=self.Nome_Estoque)
        self.combo_fruta.pack(side=LEFT, fill='x', expand=False)

        quantidade = ttk.Frame(self.Painel_Cliente)
        quantidade.pack(pady=5, padx=5, fill='x')
        label_quantidade = ttk.Label(quantidade, text="Quantidade:", font=('arial', 9))
        label_quantidade.pack(pady=5, padx=10, fill='x')

        self.quantidade_var = StringVar()
        self.entry_quantidade = ttk.Entry(quantidade, textvariable=self.quantidade_var)
        self.entry_quantidade.pack(fill='x', side=LEFT)

        btn_adicionar = ttk.Button(quantidade, text="Adicionar", command=self.adicionar_fruta)
        btn_adicionar.pack(padx=10, side=LEFT)

        label_resultado = ttk.Frame(self.Painel_Cliente)
        label_resultado.pack(pady=5, fill='x')
        self.resultado_label = ttk.Label(label_resultado, text="Aguardando seleção")
        self.resultado_label.pack()

        self.tree_cliente = ttk.Treeview(self.Painel_Cliente, columns=("Fruta", "Quantidade", "Preço"), show='headings')
        self.tree_cliente.heading("Fruta", text="Fruta")
        self.tree_cliente.heading("Quantidade", text="Quantidade")
        self.tree_cliente.heading("Preço", text="Preço (BRL)")
        self.tree_cliente.column("Fruta", anchor="center")
        self.tree_cliente.column("Quantidade", anchor="center")
        self.tree_cliente.column("Preço", anchor="center")

        self.tree_cliente.pack(padx=10, pady=10, fill='both', expand=True)

        btn_fnl_lgt = ttk.Frame(self.Painel_Cliente)
        btn_fnl_lgt.pack(pady=5, fill='x')
        btn_finalizar = ttk.Button(btn_fnl_lgt, text="Finalizar Compra", bootstyle=SUCCESS, command=self.finalizar_compra)
        btn_finalizar.pack(padx=10, pady=10, side=LEFT)
        btn_logout = ttk.Button(btn_fnl_lgt, text="Logout", bootstyle="danger", command=self.logout)
        btn_logout.pack(padx=10, pady=10, side=LEFT)

    def P_Admin(self):
        ttk.Label(self.Painel_Admin, text="Administração", font=("arial", 24)).pack(padx=10, pady=10, fill="y")

        fruta = ttk.Frame(self.Painel_Admin)
        fruta.pack(pady=5, padx=5, fill='x')
        label_fruta = ttk.Label(fruta, text="Escolha a fruta:", font=('arial', 9))
        label_fruta.pack(pady=5, padx=10, fill='x')

        self.fruta_var2 = StringVar()
        self.combo_fruta2 = ttk.Combobox(fruta, textvariable=self.fruta_var2, values=self.Nome_Estoque)
        self.combo_fruta2.pack(side=LEFT, fill='x', expand=False)

        quantidade = ttk.Frame(self.Painel_Admin)
        quantidade.pack(pady=5, padx=5, fill='x')
        label_quantidade = ttk.Label(quantidade, text="Quantidade:", font=('arial', 9))
        label_quantidade.pack(pady=5, padx=10, fill='x')

        self.quantidade_var2 = StringVar()
        self.entry_quantidade2 = ttk.Entry(quantidade, textvariable=self.quantidade_var2)
        self.entry_quantidade2.pack(fill='x', side=LEFT)

        preco = ttk.Frame(self.Painel_Admin)
        preco.pack(pady=5, padx=5, fill='x')
        label_preco = ttk.Label(preco, text="Preço:", font=('arial', 9))
        label_preco.pack(pady=5, padx=10, fill='x')

        self.preco_var = StringVar()
        self.entry_preco = ttk.Entry(preco, textvariable=self.preco_var)
        self.entry_preco.pack(fill='x', side=LEFT)

        btn_adicionar2 = ttk.Button(preco, text="Adicionar", command=self.adicionar_estoque)
        btn_adicionar2.pack(padx=10, side=LEFT)

        label_resultado2 = ttk.Frame(self.Painel_Admin)
        label_resultado2.pack(pady=5, fill='x')
        self.resultado_label2 = ttk.Label(label_resultado2, text="Aguardando seleção")
        self.resultado_label2.pack()

        self.tree_admin = ttk.Treeview(self.Painel_Admin, columns=("Fruta", "Quantidade", "Preço"), show='headings')
        self.tree_admin.heading("Fruta", text="Fruta")
        self.tree_admin.heading("Quantidade", text="Quantidade")
        self.tree_admin.heading("Preço", text="Preço (BRL)")
        self.tree_admin.pack(padx=10, pady=10, fill='both', expand=True)
        self.tree_admin.column("Fruta", anchor="center")
        self.tree_admin.column("Quantidade", anchor="center")
        self.tree_admin.column("Preço", anchor="center")

        btn_logout = ttk.Button(self.Painel_Admin, text="Logout", bootstyle="danger", command=self.logout)
        btn_logout.pack(padx=10, pady=10, side=LEFT)

    def janela_login_signUp(self):
        self.Painel_Login.pack_forget()
        self.Painel_SignUp.pack(fill="both", expand=True)

    def janela_signUp_login(self):
        self.Painel_SignUp.pack_forget()
        self.Painel_Login.pack(fill="both", expand=True)

    def Sign_Up(self):
        gmail = self.Email_Entry2.get()
        senha = self.Senha_Entry2.get()

        if gmail and senha:
            user_data.append((gmail, senha))
            self.Resultado_label2.config(text="Usuário cadastrado com sucesso!")
            self.Painel_SignUp.pack_forget()
            self.Painel_Login.pack(fill="both", expand=True)
        else:
            self.Resultado_label2.config(text="Por favor, preencha todos os campos.")

    def Login(self):
        gmail = self.Email_Entry.get()
        senha = self.Senha_Entry.get()

        if not gmail or not senha:
            self.Resultado_label.config(text="Por favor, preencha todos os campos.")
            return

        for user, password in user_data:
            if gmail == user and senha == password:
                self.Resultado_label.config(text="Login bem-sucedido")
                if gmail == "admin@gmail.com":
                    self.Painel_Login.pack_forget()
                    self.Painel_Admin.pack(fill="both", expand=True)
                    self.atualizar_tabela_admin()
                else:
                    self.Painel_Login.pack_forget()
                    self.Painel_Cliente.pack(fill="both", expand=True)
                    self.atualizar_tabela_cliente()
                return

        self.Resultado_label.config(text="Credenciais inválidas")

    def atualizar_tabela_cliente(self):
        for item in self.tree_cliente.get_children():
            self.tree_cliente.delete(item)

        for fruta, quantidade in self.Quantidade_Estoque.items():
            preco = self.Preco_Estoque[fruta]
            self.tree_cliente.insert("", "end", values=(fruta, quantidade, f"R${preco:.2f}"))

    def atualizar_tabela_admin(self):
        for item in self.tree_admin.get_children():
            self.tree_admin.delete(item)

        for fruta, quantidade in self.Quantidade_Estoque.items():
            preco = self.Preco_Estoque[fruta]
            self.tree_admin.insert("", "end", values=(fruta, quantidade, f"R${preco:.2f}"))

    def adicionar_fruta(self):
        fruta = self.combo_fruta.get()
        quantidade = self.entry_quantidade.get()

        if not fruta:
            self.resultado_label.config(text="Selecione uma fruta.")
            return

        if not quantidade.isdigit():
            self.resultado_label.config(text="Digite uma quantidade válida.")
            return

        quantidade = int(quantidade)
        if quantidade <= 0:
            self.resultado_label.config(text="Quantidade deve ser maior que zero.")
            return

        if fruta in self.Quantidade_Estoque:
            if self.Quantidade_Estoque[fruta] < quantidade:
                self.resultado_label.config(text="Quantidade em estoque insuficiente.")
                return

            self.Quantidade_Estoque[fruta] -= quantidade
            preco = self.Preco_Estoque[fruta]
            self.Valor_total += quantidade * preco
            self.fruta_selecionada.append((fruta, quantidade, preco))
            self.resultado_label.config(text=f"Fruta {fruta} adicionada. Total: R${self.Valor_total:.2f}")
            self.atualizar_tabela_cliente()
        else:
            self.resultado_label.config(text="Fruta não encontrada no estoque.")

    def adicionar_estoque(self):
        fruta = self.combo_fruta2.get()
        quantidade = self.entry_quantidade2.get()
        preco = self.entry_preco.get()

        if not fruta or not quantidade or not preco:
            self.resultado_label2.config(text="Preencha todos os campos.")
            return

        if not quantidade.isdigit():
            self.resultado_label2.config(text="Digite uma quantidade válida.")
            return

        try:
            quantidade = int(quantidade)
            preco = float(preco)
        except ValueError:
            self.resultado_label2.config(text="Digite valores válidos para quantidade e preço.")
            return

        if quantidade <= 0 or preco <= 0:
            self.resultado_label2.config(text="Quantidade e preço devem ser maiores que zero.")
            return

        if fruta in self.Quantidade_Estoque:
            self.Quantidade_Estoque[fruta] += quantidade
        else:
            self.Quantidade_Estoque[fruta] = quantidade
            self.Nome_Estoque.append(fruta)

        self.Preco_Estoque[fruta] = preco
        self.resultado_label2.config(text=f"Fruta {fruta} adicionada ao estoque com sucesso.")
        self.atualizar_tabela_admin()

    def finalizar_compra(self):
        if not self.fruta_selecionada:
            messagebox.showinfo("Finalizar Compra", "Nenhuma fruta foi selecionada.")
            return

        recibo = "Recibo de Compra:\n"
        for fruta, quantidade, preco in self.fruta_selecionada:
            recibo += f"{fruta} - Quantidade: {quantidade}, Preço: R${preco:.2f}\n"
        recibo += f"Total: R${self.Valor_total:.2f}"

        messagebox.showinfo("Recibo", recibo)
        self.fruta_selecionada = []
        self.Valor_total = 0
        self.combo_fruta.set('')
        self.entry_quantidade.delete(0, END)
        self.resultado_label.config(text="Compra finalizada com sucesso.")

    def logout(self):
        self.Painel_Cliente.pack_forget()
        self.Painel_Admin.pack_forget()
        self.Painel_Login.pack(fill="both", expand=True)
