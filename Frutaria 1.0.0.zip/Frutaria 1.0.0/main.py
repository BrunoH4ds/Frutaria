from tkinter import *
from tkinter import messagebox
import ttkbootstrap as ttk
from ttkbootstrap.style import Style
from ui import FrutariaAPP

if __name__ == "__main__":
    Janela = ttk.Window("Frutaria")
    Janela.geometry('800x700+600+150')
    Janela.iconbitmap(r"Frutaria 1.0.0\frutas.ico")
    style = Style(theme="cyborg")

    app = FrutariaAPP(Janela)
    Janela.mainloop()
